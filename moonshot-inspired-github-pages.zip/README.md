# Moonshot-inspired static website

This is an independent front-end recreation inspired by the public MakeMoonshot landing page. It is not affiliated with Moonshot and does not copy their private source code.

## Run locally
Open `index.html` in your browser.

## Publish free with GitHub Pages
1. Create a public repository on GitHub (for example `moonshot-inspired`).
2. Upload `index.html` to the repository root and commit.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Wait for deployment and open the URL shown in Pages.

The upload area is a front-end demo only: it selects a local file and shows its name. AI video editing, cloud uploads, authentication, and exporting require backend services and APIs.
